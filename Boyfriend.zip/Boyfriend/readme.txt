You've downloaded a Friday Night Funkin UTAU samples from the actual source!
The voice should be used in higher octaves (G#3 and above)
This jinrikis distribution was approved by ninjamuffin himself! please have fun using it!



!!!!IMPORTANT!!!!
please make sure to credit the following if you ever use this in a song cover.


HalfneCross for providing the jinriki & OTO
KawaiSprite as voice provider
NinjaMuffin99 as the creator of Friday night funkin
PhantomArchade for providing artwork

Engine: resampler.ddl / resampler_ug
configurations: Y0H0B0eoMb-100

