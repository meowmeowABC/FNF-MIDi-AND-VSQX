You've downloaded a Friday Night Funkin UTAU that samples from the actual source!
The voice should be used in lower octaves (A2 and above)
This jinrikis distribution was approved by BassetFilms himself! please have fun using it!



!!!!IMPORTANT!!!!
please make sure to credit the following if you ever use this in a song cover.


HalfneCross for providing the jinriki & OTO
BassetFills as voice provider
NinjaMuffin99 as the creator of Friday night funkin
PhantomArchade for providing artwork

Engine: resampler.ddl / resampler_ug
configurations: Y0H0B0C99

